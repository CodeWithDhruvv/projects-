Assignment 1 – Implementing a iPod/Zen/Zune-style Music player

PROJECT OVERVIEW
This is a playlist manager built in C, which takes 4 artists and total of 12 songs and magically makes a random shuffled playlist ensuring that no song is repeated after 5 different songs have been placed. I have used bubble sort as my sorting algorithm for sorting music artists and their music and Fisher-Yates shuffle algorithm to print our final playlist. my program is easy to understand, stores data efficiently in a single array with up to 79 characters each. As per project requirements, input of songs is also displayed at the beginning. 

FEATURES:
User input is stored in a tabular form in a single 2-dimensional array.
Sorts songs alphabetically by artist and song title.
Duplicate song placement rule ensures song reappears only after at least 5 songs.
Skip button, incase someone does not wish to add further songs or artist, they can use the keyword "skip".

ALGORITHM USED:
Bubble sort, fisher-yates shuffle.
language used- C

CODE DETAILS AND FUNCTIONS USED:

-Input: an 2-D array stores our input making the tabular form easy to visualise and loop through, our first column stores artist names whereas rows in from of artist stores their music making it a 4x4 table. To summarise, column 1 stores artist name and column 2,3,4 stores their music. I've used this approach because i found it easier to call in for loops.

principals learned while storing data include functions like:
Fgets (used to take user input and store its input)
strcspn (string 1,string 2) (used to find occurrence of string 2 in string 1)

Sorting {Bubble sort}
strcmp (compares two strings, return 0 if equal, < 0 {less than 0} if string1 comes before 	string2, and > 0 if string 1 comes before string 2.
 
strcpy(st1,st2) (copies content of st2 in st1)

how does sorting function works?
Ans. lets assume we have three cups named a b c with a,b cups filled with water and c empty,
a=c
b=a
c=b and our content is swapped!!

looping, three nested loops are used:
Outer loop (i) → Selects an artist.
Middle loop (j) → Ensures sorting is repeated for accuracy.
Inner loop (k) → Swaps adjacent songs one pass at a time.



Shuffling songs for each artist
{Fisher Yates Shuffle} - used to shuffle an array randomly, iterates backwards swapping element with random position.

Start from the last element of the array.
Generate a random index (j) between 0 and the current index (i).
Swap arr[i] with arr[j].
Repeat until the entire array is shuffled.

generateRandomPlaylist
step 1: storing and populating playlist (each song appears twice)
we use sprint to store songs in our array playlist 
sprint (used to store text data in a string, instead of printing it) sprint( destination where it needs to be stored, how it is to be stored, what needs to be stored)

step 2: shuffle playlist using fisher yates again.
step 3: ensuring no songs repeats within 5 positions. (we check for duplicate songs within 5 positions from the song selected, if duplicate is found we shift it).



-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-	end of project	-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x






  

