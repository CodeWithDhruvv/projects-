#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "sortAndShuffle.h"

void sortSongs(char songs[4][4][80])        //function caller [sortsongs] takes input from main file
{
    for (int i = 0; i < 4; i++)             //itterates through each artist, i runs form 0 to 3{0123} i.e 4 times 
    {       
        for (int j = 1; j < 3; j++)         //itterates 2 times ensuring sonngs are in correct order
                                            //itteration 1 ensures larget song comes to end, 2nd iteeration moves second largest song
        {  
            for (int k = 1; k < 4 - j; k++)     //itterates through each song for a specific artist , if i = 1, for artsit 1 it itterates 3 times
                                                //4 - j ensures largest song moves to end after each pass 
            {  
                if (strlen(songs[i][k]) > 0 && strlen(songs[i][k + 1]) > 0 &&   //check if there is valid data stored in both entries which we will compare
                    strcmp(songs[i][k], songs[i][k + 1]) > 0) // compare two adjecent songs if k is bigger than k+1 they swap places      
                    { 

                    // Swap songs if condition holds true
                    char temp[80]; //temperory variable

                    strcpy(temp, songs[i][k]);  //step 1, first song is stored in temp 
                    strcpy(songs[i][k], songs[i][k + 1]);   //step 2, overwrite song 2 in song 1
                    strcpy(songs[i][k + 1], temp);  //step 3: copy song stored in temp as song to song 2
                    //swap complete
                }
            }
        }
    }
}
void shuffleSongs(char songs[4][4][80]){    //function caller

    srand(time(NULL)); //to ensure everytime program runs, random number is generated.

    for (int i = 0 ; i < 4 ; i++){
        for (int j = 3 ; j > 0 ; j--){

            int randomIndex = 1 + (rand() % j);

            char temp[80];  //temperory variable to hold song during swapping
            strcpy(temp, songs[i][j]);  //copy song in temp to preserve its value
            strcpy(songs[i][j], songs[i][randomIndex]); //swap random chosen one with last element
            strcpy(songs[i][randomIndex], temp);    //random one is stored in last index

        }
    }
    printf("Songs shuffled randomly:\n");
}
void generateRandomPlaylist(char songs[4][4][80], char playlist[24][80]) {  //function caller
    
    int songCount = 0;

    // Step 1: Store songs in playlist (each song appears twice)
    for (int i = 0; i < 4; i++) {       //loop through artist (rows)
        for (int j = 1; j < 4; j++) {   // loop through songs (columns)
            if (strlen(songs[i][j]) > 0)    //check if there is an vaid entry
            {
                // Store song in "Artist - Song" format
                sprintf(playlist[songCount++], "%s - %s", songs[i][0], songs[i][j]);    //format string as artist - songs
                sprintf(playlist[songCount++], "%s - %s", songs[i][0], songs[i][j]);    //written twice so that song appeq
            }
        }
    }

    // Step 2: Shuffle final playlist using fisher yates again

    srand(time(NULL));  //ensure randomness

    for (int i = songCount - 1; i > 0; i--) //loop runs for all songs stored in playlist array
    {
        int j = rand() % (i + 1);   //generating random number in range [0,i]
        
        // Swap playlist[i] with playlist[j]

        char temp[80];

        strcpy(temp, playlist[i]);
        strcpy(playlist[i], playlist[j]);
        strcpy(playlist[j], temp);
    }

    // Step 3: Ensure no song repeats within 5 positions
    for (int i = 0; i < songCount - 5; i++) {  // Loop through the playlist, the last 5 songs don’t need to be checked because they won’t have enough space to violate the rule.
        for (int j = i + 1; j <= i + 5 && j < songCount; j++) {  // Check the next 5 positions if same song appears
            if (strcmp(playlist[i], playlist[j]) == 0) {  // If a duplicate is found swap position
               
                int swapIndex;
                if (j + 5 < songCount) {
                    swapIndex = j + 5;  // Move the duplicate at least 5 positions ahead
                } else {
                    swapIndex = rand() % songCount;  // Pick a random valid index as a fallback
                }
    
                // Swap the duplicate song with a farther song
                char temp[80];
                strcpy(temp, playlist[j]);
                strcpy(playlist[j], playlist[swapIndex]);
                strcpy(playlist[swapIndex], temp);
            }
        }
    }
    
    printf("\nRandom Playlist Generated!\n");
}
