#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sortAndShuffle.h"

#define MAX_ARTISTS 4
#define MAX_SONGS 4
#define MAX_LENGTH 80

int main (void){
    char Song_Table[MAX_ARTISTS][MAX_SONGS ][MAX_LENGTH];   //defining 2d table which will store user input (max length 80,to store number of charecters) 
                                                            //(4x4 table with column  1 artist and 2,3,4 stores their music)
    int i=0;

    printf("If you do not wish to enter a song/artist, please type 'skip'.\n"); //initial statement informining how to skip artist or song

    //defining statements done, storing programm starts here
    for(size_t x = 0; x < 4; ++x)         //loop runs 4 times (size_t is used for x as it ensures only positive values(good practice for inexing))
    {            
        printf("Insert an artist/group name:\n");

        fgets(Song_Table[i][0],80,stdin);
        //fgets read user input upto 79 charecters and a "\n" charecterand stores in [0][0] index,(reads from keyboard stdin)) 
    
        Song_Table[i][0][strcspn(Song_Table[i][0], "\n")] = 0;
        //converts newline charecter stored by fgets to null chrecter for easy comprison of string
        //also if user inputs skip\n, it wont be exct same keywor as ours for compiler
        

        if (strcmp(Song_Table[i][0], "skip") == 0)
        //compares string stored, if string stored is also skip (which indicates to 0 according to ASCII order, continue function does its work)
        
        {
            printf("Skipping this artist entry.\n\n");
            continue;   //loop moves one step ahead without storing anything here
        }

        
        //artist name has now been stored now its time to store their 3 songs in their rows
        
        int entered_songs = 0;              // Track if at least one song is entered

        for (int y = 1; y < 4 ; ++y)        //this loop runs 3 times (songs)
        {
            printf( "Insert song %d for %s [type 'skip' to stop adding songs]\n", y , Song_Table[i][0]);
            fgets(Song_Table[i][y],80,stdin);
            Song_Table[i][y][strcspn(Song_Table[i][y], "\n")] = 0;
            //for convinience, ive used y (same variable for loop) for shifting columns and row would be same

            if (strcmp(Song_Table[i][y], "skip") == 0) //compare entered input with skip ()
            {
                if (entered_songs == 0) 
                {
                    printf("Please enter at least one song for this artist!\n");
                    y--;    //comes back to y = 1, scontinue would progress loop by + 1 
                    continue;
                } 
                else 
                {
                    printf("Stopping song input for this artist.\n\n");
                    Song_Table[i][y][0] = '\0';     //removes the keyword skip stored in our table(we dont want to store skip as a song)
                    break;                          //comes out of loop as no more songs a\re to be entered
                }
            }
            entered_songs++;    //once a song is entered, entered song is incremented 
        }

        if (entered_songs > 0)  //after loop for songs is complete, i is increased to shift to next row and this whole loops runs 4 times completing our table
        { 
            i++;
        }
    }
    //songs  have been stored in our table 

// to print songs stored in our 4x4 table
printf("\nStored Artist and Songs:\n");

for (int m = 0; m < i; ++m) {                       //prints according to i, which refers to number of rows(astist stored)
    if (strlen(Song_Table[m][0]) == 0) 
    continue;                                       // Skip if no entry is storedin a section 

    printf("\nArtist: %s\n", Song_Table[m][0]);     // Print artist name

    for (int n = 1; n < MAX_SONGS; ++n) {           //print teir song loop runs from 1 to 3 (3 times)
        if (strlen(Song_Table[m][n]) > 0) {         //check if the song is stored
            printf("  - %s\n", Song_Table[m][n]);
        }
    }
}
//calling sort and then shuffle functions from our second file 
sortSongs(Song_Table);
shuffleSongs(Song_Table);

char randomPlaylist[24][80];
    generateRandomPlaylist(Song_Table, randomPlaylist);

    // Print Final Random Playlist
    printf("\nFinal Random Playlist:\n");
    for (int i = 0; i < 24 && strlen(randomPlaylist[i]) > 0; i++)
    {
        printf("%d. %s\n", i + 1, randomPlaylist[i]); 
    }

//ascii art of a bubble (because i like bubble sort)
/*printf("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀\n");
printf("⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⠀⠀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠞⠀⠀⠀⠐⢵⣂⠀⠀⠀⠀⠀⠀\n");
printf("⠀⠀⠀⠀⠀⢀⢤⣲⣽⣶⢲⠪⠋⠓⠛⠫⣷⣢⣄⠀⠀⠀⠀⠀⣾⠟⠀⠀⠀⠀⠀⢷⡇⠀⠀⠀⠀⠀\n");
printf("⠀⠀⠀⣠⣴⣻⣿⣿⠻⠉⠀⠀⠀⠀⠀⠀⠀⠙⣷⣥⠢⡀⠀⠀⢛⠁⠀⠀⠀⠀⠀⡻⠁⠀⠀⠀⠀⠀\n");
printf("⠀⠀⣴⡿⡹⠁⠉⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠻⡷⡐⡄⠀⠈⠓⠷⠦⣤⠴⠾⠁⠀⠀⠀⠀⠀⠀\n");
printf("⠀⢸⣿⣦⣇⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠀⣷⣿⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n");
printf("⠀⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢨⢸⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n");
printf("⢠⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢘⢾⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n");
printf("⠀⣿⣿⣏⢃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n");
printf("⠀⠘⣿⡟⠳⠦⠀⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⡀⣄⡴⠿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n");
printf("⠀⠀⠘⢿⣆⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⡟⠁⠀⣀⣤⣴⣶⡭⣵⣒⡠⢄⠀⠀⠀⠀⠀⠀⠀\n");
printf("⠀⠀⠀⠀⠙⢿⣦⣄⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣾⡿⠋⠀⢠⣶⡟⡙⠉⠈⠀⠀⠀⠁⠓⢌⢢⡄⠀⠀\n");
printf("⠀⠀⠀⠀⠀⠀⠈⠙⠻⠷⠶⣶⣶⣶⣶⡿⠿⠟⠉⠀⠀⢰⣯⡟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠈⠃⣷⡀⠁\n");
printf("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠅⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣷⠀\n");
printf("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⣿⡷⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⠀\n");
printf("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⣿⡏⠀\n");
printf("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡟⢳⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⡟⠀⠀\n");
printf("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠻⢝⣂⠀⠀⣠⢤⣤⣴⡟⠋⠀⠀⠀\n");
printf("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠁⠋⠀⠀⠀⠀⠀\n");
*/
return 0;
}