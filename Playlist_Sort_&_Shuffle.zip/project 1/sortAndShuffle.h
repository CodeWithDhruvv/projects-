//welcome to the declartion file for sort and shuffle functions 
// this file contains function declartion prototype to inform compiler about its existance 

#ifndef SORTANDSHUFFLE_H
#define SORTANDSHUFFLE_H

#define MAX_ARTISTS 4
#define MAX_SONGS 4
#define MAX_LENGTH 80

// Function Declarations
void sortSongs(char songs[4][4][80]);
void shuffleSongs(char songs[4][4][80]);
void generateRandomPlaylist(char songs[4][4][80], char playlist[24][80]);

#endif