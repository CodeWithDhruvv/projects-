//
// Created by domij on 07/03/2025.
//

#ifndef RECURSIVE_FUNCTIONS_H
#define RECURSIVE_FUNCTIONS_H
#include "Tasks.h"
void critical_path(Task total_tasks[], int tasks_count);
void check_circulars(Task total_tasks[], int task_count);
int is_circular(Task total_tasks[], Task task,  int index, int touched_on[]);

typedef struct
{
    int length; //length of path
    int path[11]; // the array of the paths elements
}Path; //struct for the path of a task

#endif //RECURSIVE_FUNCTIONS_H
