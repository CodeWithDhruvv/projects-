Gantt Chart Task Manager - Project Walkthrough
This project is a Gantt Chart Task Manager written in C. It allows users to define tasks, set dependencies, and visualize schedules using a text-based Gantt chart. The program also performs Critical Path Analysis to determine the longest sequence of dependent tasks and checks for Circular Dependencies to prevent invalid task structures.

The user can either use predefined tasks (based on historical events from Alexander the Great's conquests) or manually enter their own tasks. The program provides an interactive command-line interface for project management.

Project Structure
The project is divided into multiple C files, each handling a specific part of the functionality:

1. main.c – The entry point of the program.
2. Tasks.c – Manages task creation, editing, and dependencies.
3. recursive_functions.c – Implements critical path analysis and circular dependency detection.
4. user_functions.c – Handles user interactions and Gantt chart display.
5. Header Files (Tasks.h, recursive_functions.h, user_functions.h) – Define function prototypes and structures used in the project.

1. main.c - Program Entry Point
This file is the starting point of the program. It initializes the task list, asks the user whether to use predefined tasks or create new ones, and then calls the menu function to interact with the user.

Key Responsibilities
Initializes total_tasks[] array to store all tasks.
Asks the user whether they want to use test data or manually input tasks.
Calls menu() to display options.

2. Tasks.c - Task Management
This file is responsible for creating, editing, and managing tasks. Tasks are stored in an array, and each task has:

A Name (string)
A Start and End Month (integer values)
Dependencies (other tasks it depends on)
A Unique Task ID
Functions in Tasks.c
add_test_tasks() – Loads predefined historical tasks.
add_tasks() – Allows users to manually enter task details.
edit_tasks() – Enables modifying an existing task.

3. recursive_functions.c - Task Analysis and Validation
This file contains the recursive algorithms that:

Find the longest dependency chain (Critical Path Analysis).
Detect circular dependencies (Invalid task loops).
Functions in recursive_functions.c
longest_path() – Finds the longest chain of dependent tasks.
critical_path() – Finds the overall longest sequence.
is_circular() – Detects circular dependencies.
check_circulars() – Runs a global check for cycles.


4. user_functions.c - User Interaction and Gantt Chart Display
This file handles everything the user sees:

Displays the Gantt chart.
Provides menu options for editing and testing.
Formats the output to make it readable.
Functions in user_functions.c
display_gantt() – Prints a structured Gantt chart.
menu() – Manages user interactions.


This project is a simple and effective way to manage and analyze tasks using a Gantt chart. It helps users define tasks, set dependencies, and check for scheduling issues like circular dependencies. The program is well-structured, making it easy to understand and modify. It also uses recursion to analyze task dependencies efficiently. In the future, features like saving tasks to a file, better error handling, and a graphical interface could make it even more useful. Overall, this project provides a solid foundation for understanding task scheduling and project management in C.

