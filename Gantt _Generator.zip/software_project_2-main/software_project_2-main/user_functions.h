//
// Created by domij on 02/03/2025.
//
// Header file for user interaction functions in the Gantt chart generator.
//

#ifndef USER_FUNCTIONS_H  // Prevent multiple inclusions
#define USER_FUNCTIONS_H

#include "Tasks.h" // Include task structure and related functions

int display_or_create();


void display_gantt(Task total_tasks[], int tasks_count, const char *months[]);


void gantt_row(Task task);

void print_divider();
void menu(Task total_tasks[], int tasks_count, const char *months[]);
#endif // USER_FUNCTIONS_H