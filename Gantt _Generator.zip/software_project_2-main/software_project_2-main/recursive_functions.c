//
// Created by domij on 07/03/2025.
//
#define MAX_TASKS 10
#include "recursive_functions.h"
#include "tasks.h"
#include <stdio.h>
#include <string.h>

Path longest_path(Task total_tasks[], int task_id, int tasks_count, int stack[]) //finds the longest path for each task
{
    Task task = total_tasks[task_id-1]; //intialises the task
    Path longest; // Variable to hold the longest path that stems from the tasks dependencies
    longest.length = 0; //initalise longest length

    if (stack[task_id] == 1) //a base case, if the task has already been visited in the recursive stack
    {
        longest.path[0] = task_id; //add task to path
        longest.path[1] = -1; // mark circular dependency
        longest.length = 1; //set length to one
        return longest;
    }

    stack[task_id] = 1; //set task as visited

    if (task.dependencies_count == 0) //another base case, if task has no dependencies
    {
        longest.length = 1;
        longest.path[0] = task_id;
        stack[task_id] = 0; //reset status  to unvisited before returning
        return longest;
    }

    for (int i = 0; i < task.dependencies_count; i++) //else
    {
        //recursive step
        Path sub_path = longest_path(total_tasks, task.dependencies[i], tasks_count , stack); //sub_path to store any paths stemming from current task

        // check for circular dependency marker (-1 in path)
        if (sub_path.path[sub_path.length] == -1)
        {
            sub_path.path[sub_path.length++] = task_id; //add as final element
            stack[task_id] = 0; //reset status
            return sub_path;  //return from the recursion
        }

        if (sub_path.length > longest.length) //if subpath legnth is longer than the previous longest length
        {
            longest = sub_path;  //update the longest path to the subpath
        }
    }

    longest.path[longest.length] = task_id; //add the element into the path of the longest path
    longest.length++; //increment

    stack[task_id] = 0; //reset visit status
    return longest; //return longest path of this task
}

void critical_path(Task total_tasks[], int tasks_count)
{
    Path critical_path; //Path struct to hold properties of the critical path
    critical_path.length = 0; //initialise length to 0

    for (int i = 0; i < tasks_count; i++) //loop through all tasks
    {
        Task current = total_tasks[i]; //current task variable in loop
        int stack[MAX_TASKS] = {0}; //initialise stack inorder to stop infinite recursion
        Path current_path = longest_path(total_tasks, current.task_id, tasks_count, stack); //find longest path of the i'th task

        if (current_path.length > critical_path.length) //if this tasks path is longer than previous
        {
            critical_path = current_path; //update
        }
    }

    printf("\nCritical Path: \n");
    int printed[MAX_TASKS] = {0}; //flags to determine if a task has already been printed
    for (int i = critical_path.length - 1; i >= 0; i--) //start from most recent task
    {
        if (printed[critical_path.path[i]]) // if task has already been printed
        {
            printf(" ( !!!!!!!!!! warning potential circular dependency !!!!!!!!!!!!!!) ");
            break; //stop printing
        }
        printed[critical_path.path[i]] = 1; //set flag to true
        printf("%d -> ", critical_path.path[i]); //else print element
    }
}


int is_circular(Task total_tasks[], Task task, int tasks_count, int touched_on[]) //function to check if a task is circular
{

     if (touched_on[task.task_id] == 1) //if the task has already been visited
     {
         return 1; //return true
     }
      touched_on[task.task_id] = 1; // set visit status to true
      if(task.dependencies_count == 0) //base case, if no dependencies
      {
           touched_on[task.task_id] = 0; //reset flag to false before returning
           return 0;
      }

      for (int i = 0; i < task.dependencies_count; i++) //loop through tasks's dependencies
      {
                // recursion, if any of this tasks dependencies lead to a circle
              if (is_circular(total_tasks, total_tasks[task.dependencies[i] - 1], tasks_count,  touched_on))
              {
                  return 1; //its true...
              }
      }
      touched_on[task.task_id] = 0; //if none do, reset flag to false
      return 0; //return false
}

//loop through all tasks, to see if any lead to circular dependency
void check_circulars(Task total_tasks[], int task_count)
{

    int touched_on[MAX_TASKS]; //array of flags to determine if task has been visited
    int any_circular = 0; //flag to determine if there are any circular dependencies
    for (int i = 0; i < task_count; i++)
    {
        memset(touched_on, 0, sizeof(touched_on));//set all flags to false for each loop
       if (is_circular(total_tasks, total_tasks[i], task_count, touched_on) != 0)
         {
               any_circular = 1; //flag to true
               printf("\nTEST RESULT : !!! Circular Dependency Found!!!");
               memset(touched_on, 0, sizeof(touched_on)); //reinitiialise to 0
               return;
         }
    }
     if(!any_circular) // if flag never becomes true
    {
          printf("\nTEST RESULT: No circular dependencies found!");
    }
}