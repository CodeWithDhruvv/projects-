//
//  Created by domij on 02/03/2025.
//  entry point of the program. It initializes tasks, interacts with the user, and calls functions from other files.
#include <stdio.h>
#include "user_functions.h"
#include  "Tasks.h"
#include "recursive_functions.h"
#define MAX_TASKS 10


int main(void)
{
    //array of months for gantt
    const char *months[] = {"January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"};

    Task total_tasks[MAX_TASKS]; //Array of All Tasks
    int tasks_count = 0;

    if (display_or_create() == 0) //if this function returns 0,  add test data
    {
        add_test_tasks(total_tasks, &tasks_count);
    }
    else //else if it displays 1 , commence add_tasks function
    {
        add_tasks(total_tasks, &tasks_count);
    }

    menu(total_tasks, tasks_count, months); //menu

    //ascii art, a greek temple as the predefined tasks were based on Alexander the Great's Life
    printf("            _______________________\n");
    printf("           /                       \\\n");
    printf("          /_________________________\\\n");
    printf("         |___________________________|\n");
    printf("     ____||____  ____  ____  ____  ____||____\n");
    printf("    ||    ||    ||    ||    ||    ||    ||    ||\n");
    printf("    ||    ||    ||    ||    ||    ||    ||    ||\n");
    printf("    ||    ||    ||    ||    ||    ||    ||    ||\n");
    printf("    ||    ||    ||    ||    ||    ||    ||    ||\n");
    printf("    ||____||____||____||____||____||____||____||\n");
    printf("  =============================================\n");
    printf("  |                                           |\n");
    printf("  |___________________________________________|\n");
    return 0;
}

