//
// Created by domij on 02/03/2025.
// Manages menu, Gantt chart display, and user interactions.

#include "user_functions.h"
#include <stdio.h>
#include <string.h>
#include "tasks.h"
#include <stdlib.h>

#include "recursive_functions.h"

//function to clear screen
void clear_screen()
{
#ifdef _WIN32
    system("cls");  // If Windows
#else
    system("clear"); // If Mac Or Linux
#endif
}

// Function to print a divider line
void print_divider()
{
    printf("+----------------------"); //task name column
    for (int i = 0; i < 12; i++)
    {
        printf("+---------"); // month columns (7 characters each)
    }
    printf("+------------------------+\n"); // Dependencies column (15 characters)
}

// Function to display the Gantt chart
void display_gantt(Task total_tasks[], int tasks_count, const char *months[])
{
    // Clear the screen
    clear_screen();

    // Print the header row
    print_divider();
    printf("| %-20s ", "Task Name"); //task name
    for (int i = 0; i < 12; i++)
    {
        printf("| %-7s ", months[i]); // Month headers
    }
    printf("| Dependencies  |\n");
    print_divider();

    // Print each task row
    for (int i = 0; i < tasks_count; i++)
    {
        gantt_row(total_tasks[i]);
    }

    // Print the final divider
    print_divider();
}


// Function to display a single row of the Gantt chart
void gantt_row(Task task)
{
    printf("| %-20s ", task.name); // task name (left-aligned, 20 characters wide)

    // display months (XXX for active months, empty otherwise)
    for (int i = 0; i < 12; i++)
    {
        if (task.start - 1 <= i && i <= task.end - 1)
        {
            printf("| %-7s ", "XXX");
        }
        else
        {
            printf("| %-7s ", " ");
        }
    }

    // Display dependencies
    printf("| ");
    int amount = 6;
    for (int i = 0; i < task.dependencies_count; i++)
    {
        printf("%-3d", task.dependencies[i]);
      //  amount ;
    }
    for (int i = task.dependencies_count; i < amount; i++) // more spaces for allignment
    {
        printf("   ");
    }
    printf(" |\n");
}




void menu(Task total_tasks[],int tasks_count, const char *months[] )
{
    while (1)
    {
        display_gantt(total_tasks, tasks_count, months);
        char menu_option[20]; //menu option input
        printf("\nIf you wish to edit the Gantt please type 'edit' / If you wish to run a test, type 'test' or to exist type 'quit' and then press enter to execute your option.\n");
        fgets(menu_option, sizeof(menu_option), stdin);
        menu_option[strcspn(menu_option, "\n")] = 0; // remove the newline character



        if (strcmp(menu_option, "edit") == 0) //if edit
        {
            char input[3]; //input for if the user wants to see the edited gantt
            edit_tasks(total_tasks, tasks_count);
            printf("\nWould you like the view the modified gantt? (yes or no)\n");
            scanf("%s", input);
            //fgets(input, sizeof(input), stdin);
           // input[strcspn(input, "\n")] = 0;
            if (strcmp(input, "yes") == 0)
            {
                display_gantt(total_tasks, tasks_count, months);
            }
            else
            {
                return ; //else end the program
            }


        }
        else if (strcmp(menu_option, "test") == 0) //if test
        {
            printf("\nFinding the Critical Path...\n");
            critical_path( total_tasks, tasks_count); //print crit path
            printf("\n\nSearching for Circular Dependencies...\n");//check if any circs exist
            check_circulars(total_tasks,tasks_count);
            printf("\n\nWould you like to return to the menu?\n");
            char input[3];
            fgets(input, sizeof(input), stdin);
            input[strcspn(input, "\n")] = 0;
            if (strcmp(input, "no") == 0)
            {
                return; //if no quit
            }
            //else return to menu
        }
        else if (strcmp(menu_option, "quit") == 0)
        {
            return; //if quit, end program
        }
    }
}

int display_or_create() // Function to start the program
{

    while (1) // Keep asking until valid input is received
    {
        char input[10];
        printf("Welcome to the Gantt Generator\nWould you like to use the test example or create your own Gantt from scratch? (yes or no)\n");
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = 0;

        if (strcmp(input, "yes") == 0)
        {
            return 0; // Return 0 if test example
        }
        else if (strcmp(input, "no") == 0)
        {
            return 1; // Return 1 if user wants to create their own Gantt
        }
        else
        {
            printf("\nERROR 001: Input must be 'yes' or 'no'!\n\n");
        }
    }
}

