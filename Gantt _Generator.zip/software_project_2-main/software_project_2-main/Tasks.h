// Created by domij on 02/03/2025.
//

#ifndef TASKS_H  //  Prevent multiple inclusions
#define TASKS_H

#define MAX_TASKS 10  //  Maximum number of tasks allowed in the Gantt chart

//  Structure representing a task in the Gantt chart
typedef struct
{
    char name[50]; // Task name (max 50 characters)

    int start; // Start month (1-12)
    int end;   // End month (1-12)

    int dependencies[10]; // Array storing indices of dependent tasks
    int dependencies_count; // Number of dependent tasks
    int task_id; //numerical id of the task
} Task;

//


void add_test_tasks(Task total_tasks[], int *tasks_count);


void add_tasks(Task total_tasks[], int *tasks_count);


void edit_tasks(Task total_tasks[], int tasks_count);

#endif // TASKS_H