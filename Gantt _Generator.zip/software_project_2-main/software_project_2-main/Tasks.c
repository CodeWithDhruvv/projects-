//
// Created by domij on 02/03/2025.
// Handles task creation, modification, and dependencies.

#include "Tasks.h"
#include <stdio.h>
#include <string.h>
#define MAX_TASKS 10


void add_test_tasks(Task total_tasks[], int *tasks_count)
{
    //modelling the tasks after alexander the great's life
    Task tasks [10] =
    {
        {"Claim Throne", 1, 2, {}, 0,1},
        {"Consolidate Greece", 2,4,{1},1,2},
        {"Assemble Army", 3, 5, {1,2} ,2,3},
        {"Conquer Asia Minor",5,6,{3},1,4 },
        {"Cross the Hellespont",6,8,{3},1,5},
        {"Battle of Issus", 7,8, {4},1,6},
        {"Conquer Egypt", 7,8,{6},1,7},
        {"Found Alexandria", 8,9,{7},1,8},
        {"Siege of Tyre", 9, 11, {6},1,9},
        {"Battle of Gaugamela",10,12,{1,7,8},2,10}
    };

    *tasks_count = 10; // hard-coding the amount of tasks
    for (int i = 0; i < 10; i++)
    {
        total_tasks[i] = tasks[i]; //adding tasks to the global task array
    }
}


void add_tasks(Task total_tasks[], int *tasks_count) //handles user input to store tasks for a gantt
{
    int entry_counts; //num of tasks input, to be added to total_tasks pointer
    char buffer[10]; //input for amount of tasks

    while(1)
    {
        printf("\nHow many tasks would you like to add? (1-10)\n");
        fgets(buffer, sizeof(buffer), stdin);
        if(sscanf(buffer, "%d", &entry_counts) != 1 || entry_counts < 1 || entry_counts > MAX_TASKS) //convert fgets to scanf to read int, and stores in entery_counts
        {
            printf("\nERROR 002: Must be between 1 and 10 tasks\n"); //error validation
        }
        else
        {
            break;
        }
    }

    *tasks_count = entry_counts; //update task count using pointer

    for(int i = 0; i < entry_counts; i++)
    {
        Task entry_task; //declare task
        char temp_buffer[10];

        printf("\nEnter Task Name\n");
        fgets(entry_task.name, sizeof(entry_task.name), stdin); //read task name
        entry_task.name[strcspn(entry_task.name, "\n")] = 0; //remove \n

        //read months
        printf("Start Month (1-12)\n");
        fgets(temp_buffer, sizeof(temp_buffer), stdin);
        sscanf(temp_buffer, "%d", &entry_task.start);

        printf("End Month (1-12)\n");
        fgets(temp_buffer, sizeof(temp_buffer), stdin);
        sscanf(temp_buffer, "%d", &entry_task.end);

        //read dependency count
        printf("Enter how many dependencies this task has\n");
        fgets(temp_buffer, sizeof(temp_buffer), stdin);
        sscanf(temp_buffer, "%d", &entry_task.dependencies_count);

        //enter dependencies
        for(int j = 0; j < entry_task.dependencies_count; j++)
        {
            printf("Enter dependent task\n");
            fgets(temp_buffer, sizeof(temp_buffer), stdin);
            sscanf(temp_buffer, "%d", &entry_task.dependencies[j]);
        }

        entry_task.task_id = i + 1; //apply the task id
        //add task to total task array
        total_tasks[i] = entry_task;
    }
}


void edit_tasks(Task total_tasks[], int tasks_count) //handles gantt modification, for menu
{
    char task_name[30]; //initialise task name
    int task_found = 0; //boolean to determine if the task that the user wishes to chnage exists
    int edited_task_index; //index of the edited task within the total task array
    Task edited_task; //initialise edited task
    char buffer[10];

    while(!task_found) //while the task is not found in the total task array
    {
        printf("\nPlease enter the task name you wish to change exactly \n");
        fgets(task_name, sizeof(task_name), stdin);
        task_name[strcspn(task_name, "\n")] = 0; //store name of task that wishes to be edited

        for(int i = 0; i < tasks_count; i++) //loop through to determine if the task exists
        {
            if(strcmp(task_name, total_tasks[i].name) == 0) // the task is found
            {
                task_found = 1; //task found is true
                edited_task_index = i; //read index for the edited task
                break;
            }
        }
        if (!task_found)
        {
            printf("\nERROR 003: Task not found\n");
        }
    }

    //similar to the code seen in add_tasks(), enter properties for the edited task
    printf("\nPlease enter the new task name or write its old one \n");
    fgets(edited_task.name, sizeof(edited_task.name), stdin);
    edited_task.name[strcspn(edited_task.name, "\n")] = 0;

    printf("Start Month (1-12)\n");
    fgets(buffer, sizeof(buffer), stdin);
    sscanf(buffer, "%d", &edited_task.start);

    printf("End Month (1-12)\n");
    fgets(buffer, sizeof(buffer), stdin);
    sscanf(buffer, "%d", &edited_task.end);

    printf("Enter how many dependencies this task has\n");
    fgets(buffer, sizeof(buffer), stdin);
    sscanf(buffer, "%d", &edited_task.dependencies_count);

    for(int j = 0; j < edited_task.dependencies_count; j++)
    {
        printf("Enter dependent task\n");
        fgets(buffer, sizeof(buffer), stdin);
        sscanf(buffer, "%d", &edited_task.dependencies[j]);
    }

    edited_task.task_id = edited_task_index + 1;

    total_tasks[edited_task_index] = edited_task; //replace old task with modified version
}
