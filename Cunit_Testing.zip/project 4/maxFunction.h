/*
 * maxFunction.h
 *
 *  Created on: 17 Apr 2017
 *      Author: liliana
 */

#ifndef MAXFUNCTION_H_
#define MAXFUNCTION_H_

/*
 * Returns the maximum between 2 integers
 * given as input
 */
int maxi(int i1, int i2);

#endif /* MAXFUNCTION_H_ */


