#include <stdio.h>
#include <CUnit.h>
#include <Basic.h>

// functions for average and maximum
double average(double arr[], int size){                                                                                                     
    if (size == 0) {        //base case, if size is 0 (nothing entered, return 0)
        return 0;           //return 0;
    }
    double sum = 0;         //variable initialization
    for (int i = 0; i < size; i++) {    //loop to move through every elemnet
        sum += arr[i];                  //adding up all values to find total value
    }
    return sum / size;                  // average = total sum/ number of observations
}

// function to find maximum number in given array
double maximum(double arr[], int size) {            //function prototype 
    if (size == 0) return 0;                        // base case, if nothing enetered, return 0
    double max = arr[0];                            // temperorily assuming first elemnet is maximum value
    for (int i = 1; i < size; i++) {                //loop to travers thorugh each element
        if (arr[i] > max) max = arr[i];             // if an element is greater than our assumed value, update max
    }
    return max;                                     //return max 
}

// Test Cases 
// This function tests different cases for the average() function
void test_average_cases() {
    double a1[] = {1.0, 2.0, 3.0};                        // normal case with 3 positive numbers
    CU_ASSERT_DOUBLE_EQUAL(average(a1, 3), 2.0, 0.001);   // expected average is 2.0

    double a2[] = {0.0};                                  // array with only one element (zero)
    CU_ASSERT_DOUBLE_EQUAL(average(a2, 1), 0.0, 0.001);   // average should be 0.0

    double a3[] = {};                                     // empty array case
    CU_ASSERT_DOUBLE_EQUAL(average(a3, 0), 0.0, 0.001);   // no numbers, average is 0.0

    double a4[] = {-2.0, 2.0};                            // mix of negative and positive
    CU_ASSERT_DOUBLE_EQUAL(average(a4, 2), 0.0, 0.001);   // (-2 + 2)/2 = 0.0
    

}

// This function tests different cases for the maximum() function
void test_maximum_cases() {
    double m1[] = {1.0, 5.0, 3.0};                        // regular case with 3 positive numbers
    CU_ASSERT_DOUBLE_EQUAL(maximum(m1, 3), 5.0, 0.001);   // 5.0 is the highest

    double m2[] = {-1.0, -3.0, -5.0};                     // all negative numbers
    CU_ASSERT_DOUBLE_EQUAL(maximum(m2, 3), -1.0, 0.001);  // -1.0 is the maximum here

    double m3[] = {4.2};                                  // only one element in array
    CU_ASSERT_DOUBLE_EQUAL(maximum(m3, 1), 4.2, 0.001);   // max is the only element

    double m4[] = {};                                     // empty array
    CU_ASSERT_DOUBLE_EQUAL(maximum(m4, 0), 0.0, 0.001);   // nothing to compare, returns 0.0

    double m5[] = {0.0, -2.0, -5.0};                          // array with 0, checking if it is correctly picked as max
    CU_ASSERT_DOUBLE_EQUAL(maximum(m5, 3), 0.0, 0.001);       // 0 is highest here

    double m6[] = {2.0, 2.0, 5.0};                            // some elements are same, 5 is still max
    CU_ASSERT_DOUBLE_EQUAL(maximum(m6, 3), 5.0, 0.001);       // max is 5

} 


// Main Test Runner 
int main() {
    CU_initialize_registry(); // initialize the test registry (CUnit setup)

    // Add a test suite for average() tests
    CU_pSuite avgSuite = CU_add_suite("Average Suite", 0, 0); 
    CU_add_test(avgSuite, "Test Average", test_average_cases);  // add test case for average

    // Add a test suite for maximum() tests
    CU_pSuite maxSuite = CU_add_suite("Maximum Suite", 0, 0); 
    CU_add_test(maxSuite, "Test Maximum", test_maximum_cases);  // add test case for maximum

    CU_basic_set_mode(CU_BRM_VERBOSE);      // set output mode to verbose (detailed output)
    CU_basic_run_tests();                   // run all tests
    CU_cleanup_registry();                  // clean up after tests are done

    return 0;   // return success
}

