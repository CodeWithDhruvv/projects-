#include <stdio.h>
#include <stdlib.h> //for malloc(), free(), exit()
#include <string.h> //for strcpy(), strcmp(), strcspn(), strlen()

#define MAX_NAME 100    // maximum size of character or task name strings

// board structure containing pointer to first list
struct Board {
    struct List* head;            // pointer to first character list
};

// structure for tasks in each list
struct Item {
    char name[MAX_NAME];          // stores task name (example: "Sniper Rifle")
    struct Item* next;            // pointer to next task (linked list)
};

// structure for each list on the board (like each character)
struct List {
    char name[MAX_NAME];          // stores character/list name (example: "Michael")
    struct Item* item_head;       // points to first task in the list
    struct List* next;            // pointer to next list (linked list)
};



// function to create a new character/list
struct List* create_list(const char* name) {
    struct List* new_list = malloc(sizeof(struct List));     // allocate memory for new list 
    strcpy(new_list->name, name);                            // copy name into list
    new_list->item_head = NULL;                              // no tasks yet in new list
    new_list->next = NULL;                                   // next list is also NULL initially
    return new_list;                                         // return pointer to the list created
}

// function to add task/item to an existing list
void add_item(struct List* list, const char* task_name) {
    
    struct Item* new_item = malloc(sizeof(struct Item));     // allocate memory for new task
    strcpy(new_item->name, task_name);                       // copy task name
    new_item->next = NULL;                                   // new task will be the last item (initially)

    if (list->item_head == NULL) {                           // if the list has no tasks yet
        list->item_head = new_item;                          // directly add first task
    } else {
        struct Item* temp = list->item_head;                 // start from the first item
        while (temp->next != NULL) {                         // traverse to the last item
            temp = temp->next;
        }
        temp->next = new_item;                               // link the new item at the end
    }
}

// function to add a new character/list to the board
void add_list(struct Board* board, struct List* new_list) {
    if (board->head == NULL) {                               // if board is empty
        board->head = new_list;                              // set head to new list
    } else {
        struct List* temp = board->head;                     // start from first character
        while (temp->next != NULL) {                         // traverse to the end of character list
            temp = temp->next;
        }
        temp->next = new_list;                               // add new character at the end
    }
}

// function to display the board (all characters and their tasks)
void display_board(struct Board* board) {
    struct List* list_ptr = board->head;                     // pointer to each character
    while (list_ptr != NULL) {                               // traverse through each character
        printf("%s:\n", list_ptr->name);                     // print character name
        struct Item* item_ptr = list_ptr->item_head;         // pointer to tasks in that character
        while (item_ptr != NULL) {                           // traverse through tasks
            printf("    %s\n", item_ptr->name);              // print task with indent
            item_ptr = item_ptr->next;                       // move to next task
        }
        list_ptr = list_ptr->next;                           // move to next character
    }
}

// menu system to interact with user
int display_menu(){
    int choice;                                 // integer to store user input
    printf("\nMenu:\n1. Display board\n2. Load board from a file\n3. Edit list\n4. Edit Board\n5. Save board to a file\n6. Quit\n\n");  // menu option for user to understand what each option refers to
    while (1){                                  // loop does not exit until valid input is entered
        printf("Enter your choice (1-6): \n");  // ask user for input
        scanf("%d",&choice);                    // store input in choice variable
        while (getchar()!= '\n');               // keeps reading until newline (\n) is reached to flush buffer

        if (choice >=1 && choice <=6 ){         // only if user input is between 1 and 6 (inclusive)
            return choice;                       // loop breaks and we get the choice entered by user
        }   
        else {
            printf("Enter a valid input!!\n");  // warning message if invalid input (loop continues)
        }
    }
}
void save_board_to_file(struct Board* board, const char* filename) {
    FILE* file = fopen(filename, "w");                          // open file in write mode
    if (file == NULL) {
        printf("Error: Could not open file %s for writing.\n", filename);   //to check wewere successfull in opening the file 
        return;
    }

    struct List* list_ptr = board->head;                        // start from first character
    while (list_ptr != NULL) {
        fprintf(file, "%s:\n", list_ptr->name);                 // write character name

        struct Item* item_ptr = list_ptr->item_head;
        while (item_ptr != NULL) {
            fprintf(file, "%s\n", item_ptr->name);              // write each task
            item_ptr = item_ptr->next;
        }

        list_ptr = list_ptr->next;                              // move to next character
    }

    fclose(file);                                               // close file
    printf("Board saved successfully to %s!\n", filename);      // success message
}
void load_board_from_file(struct Board* board, const char* filename) {

    FILE* file = fopen(filename, "r");                          // open file in read mode
    if (file == NULL) {
        printf("Error: Could not open file %s for reading.\n", filename);
        return;
    }

    char line[MAX_NAME];
    struct List* current_list = NULL;                          // pointer to the list we're currently adding tasks to

    while (fgets(line, sizeof(line), file)) {                  // read file line by line
        line[strcspn(line, "\n")] = '\0';                      // remove newline character

        if (strlen(line) == 0) continue;                       // skip empty lines

        if (line[strlen(line) - 1] == ':') {                   // if line ends with ':', it's a new character
            line[strlen(line) - 1] = '\0';                     // remove the ':'
            current_list = create_list(line);                  // create the list
            add_list(board, current_list);                     // add list to the board
        } 
        else if (current_list != NULL) {
            add_item(current_list, line);                      // add task to the current list
        }
    }

    fclose(file);                                              // close file
    printf("Board loaded successfully from %s!\n", filename);  // success message
}

// function to find a character/list by name from the board
struct List* find_list(struct Board* board, const char* name) {
    struct List* temp = board->head;                      // start from the first list
    while (temp != NULL) {
        if (strcmp(temp->name, name) == 0) {              // compare names (case-sensitive)
            return temp;                                  // found the matching character/list
        }
        temp = temp->next;                                // move to next character
    }
    return NULL;                                          // not found
}

// function to delete a task from a character list
void delete_task(struct List* list, const char* task_name) {
    struct Item* current = list->item_head;        // start from the first task
    struct Item* prev = NULL;                      // to keep track of previous node

    while (current != NULL) {                      // traverse till we find the task
        if (strcmp(current->name, task_name) == 0) {   // if task name matches
            if (prev == NULL) {                        // if it's the first task
                list->item_head = current->next;       // just shift head
            } else {
                prev->next = current->next;            // remove current from list
            }
            free(current);                             // free memory of deleted task
            printf("Task '%s' deleted successfully.\n", task_name);
            return;
        }
        prev = current;
        current = current->next;                   // move to next task
    }
    printf("Task not found.\n");                   // if task doesn't exist
}

// function to rename a task from old_name to new_name
void rename_task(struct List* list, const char* old_name, const char* new_name) {
    struct Item* current = list->item_head;        // start from first task
    while (current != NULL) {
        if (strcmp(current->name, old_name) == 0) {    // check if task matches
            strcpy(current->name, new_name);           // copy new name into task
            printf("Task renamed successfully.\n");
            return;
        }
        current = current->next;                   // move to next task
    }
    printf("Task not found.\n");                   // if task not found
}

// function to edit tasks of a selected character/list
void edit_list(struct Board* board) {
    char name[MAX_NAME];
    printf("Enter the character/list name to edit: ");
    fgets(name, sizeof(name), stdin);                      // take input
    name[strcspn(name, "\n")] = '\0';                      // remove newline

    struct List* list = find_list(board, name);            // find character in board
    
    if (list == NULL) {                                    // if not found
        printf("Character/list '%s' not found.\n", name);
        return;
    }

    int choice;
    while (1) {
        // show task editing menu
        printf("\nEditing %s's list:\n", list->name);
        printf("1. Add task\n2. Delete task\n3. Rename task\n4. Back to main menu\n");
        printf("Enter your choice: (between 1 to 4) ");
        scanf("%d", &choice);
        while (getchar() != '\n');                         // clear buffer

        if (choice == 1) {
            char task_name[MAX_NAME];
            printf("Enter new task name: ");
            fgets(task_name, sizeof(task_name), stdin);    // input task
            task_name[strcspn(task_name, "\n")] = '\0';
            add_item(list, task_name);                     // add task
            printf("Task added successfully.\n");

        } else if (choice == 2) {
            char task_name[MAX_NAME];
            printf("Enter task name to delete: ");
            fgets(task_name, sizeof(task_name), stdin);    // input task
            task_name[strcspn(task_name, "\n")] = '\0';
            delete_task(list, task_name);                  // delete task

        } else if (choice == 3) {
            char old_name[MAX_NAME], new_name[MAX_NAME];
            printf("Enter current task name: ");
            fgets(old_name, sizeof(old_name), stdin);      // input old task name
            old_name[strcspn(old_name, "\n")] = '\0';

            printf("Enter new task name: ");
            fgets(new_name, sizeof(new_name), stdin);      // input new name
            new_name[strcspn(new_name, "\n")] = '\0';

            rename_task(list, old_name, new_name);         // rename task

        } else if (choice == 4) {
            printf("Returning to main menu...\n");
            break;                                          // exit to main menu

        } else {
            printf("Invalid choice. Try again.\n");        // if wrong option
        }
    }
}

void delete_list(struct Board* board, const char* name) {
    struct List* current = board->head;
    struct List* prev = NULL;

    while (current != NULL) {
        if (strcmp(current->name, name) == 0) {                 // if match found
            if (prev == NULL) {
                board->head = current->next;                    // deleting first node
            } else {
                prev->next = current->next;                     // unlink the node
            }

            // free all tasks in that character
            struct Item* task = current->item_head;
            while (task != NULL) {
                struct Item* temp = task;
                task = task->next;
                free(temp);
            }

            free(current);                                      // free the character/list
            printf("Character '%s' deleted successfully.\n", name);
            return;
        }
        prev = current;
        current = current->next;
    }
    printf("Character not found.\n");                           // if not found
}

void rename_list(struct Board* board, const char* old_name, const char* new_name) {
    struct List* list = find_list(board, old_name);             // find the list
    if (list == NULL) {
        printf("Character '%s' not found.\n", old_name);
        return;
    }
    strcpy(list->name, new_name);                               // update the name
    printf("Character renamed to '%s'.\n", new_name);
}

void edit_board(struct Board* board) {
    int choice;
    while (1) {
        printf("\nEdit Board:\n");
        printf("1. Add character/list\n");
        printf("2. Delete character/list\n");
        printf("3. Rename character/list\n");
        printf("4. Back to main menu\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        while (getchar() != '\n');  // clear input buffer

        if (choice == 1) {
            char name[MAX_NAME];
            printf("Enter new character/list name: ");
            fgets(name, sizeof(name), stdin);
            name[strcspn(name, "\n")] = '\0';

            if (find_list(board, name)) {
                printf("Character already exists.\n");
            } else {
                struct List* new_list = create_list(name);
                add_list(board, new_list);
                printf("Character '%s' added.\n", name);
            }

        } else if (choice == 2) {
            char name[MAX_NAME];
            printf("Enter character name to delete: ");
            fgets(name, sizeof(name), stdin);
            name[strcspn(name, "\n")] = '\0';

            delete_list(board, name);

        } else if (choice == 3) {
            char old_name[MAX_NAME], new_name[MAX_NAME];
            printf("Enter character name to rename: ");
            fgets(old_name, sizeof(old_name), stdin);
            old_name[strcspn(old_name, "\n")] = '\0';

            printf("Enter new name: ");
            fgets(new_name, sizeof(new_name), stdin);
            new_name[strcspn(new_name, "\n")] = '\0';

            rename_list(board, old_name, new_name);

        } else if (choice == 4) {
            printf("Returning to main menu...\n");
            break;
        } else {
            printf("Invalid choice. Try again.\n");
        }
    }
}

// main function
int main() {
    struct Board gta_board;                     // create board named as gta_board
    gta_board.head = NULL;                      // initially board is empty,

    // Create GTA 5 characters as lists and their tasks
    struct List* michael = create_list("Michael");
    add_item(michael, "The Jewel Store Job");
    add_item(michael, "Sniper Rifle");

    struct List* franklin = create_list("Franklin");
    add_item(franklin, "Buffalo S");
    add_item(franklin, "Chop the Dog");

    struct List* trevor = create_list("Trevor");
    add_item(trevor, "Rampage: Military");
    add_item(trevor, "Blaine County Airfield");
    add_item(trevor, "Minigun");

    struct List* lamar = create_list("Lamar");
    add_item(lamar, "Hood Safari");
    add_item(lamar, "Green Sabre");

    // Add character lists to the board
    add_list(&gta_board, michael);
    add_list(&gta_board, franklin);
    add_list(&gta_board, trevor);
    add_list(&gta_board, lamar);

    // Menu interaction with user
    int choice;
    while (1) {
        choice = display_menu();                        // get user input from menu

        if (choice == 1) {
            printf("\n=== GTA 5 Kanban Board ===\n\n"); // display board if user chooses 1
            display_board(&gta_board);
        }

        else if (choice == 2) {
            char filename[100];
            printf("Enter filename to load the board from (e.g., board.txt): ");
            fgets(filename, sizeof(filename), stdin);                   // read filename
            filename[strcspn(filename, "\n")] = '\0';                   // remove newline
            load_board_from_file(&gta_board, filename);                 // call the load function
        }

        else if (choice == 3) {
            edit_list(&gta_board);      // call the edit list function
        }

        else if (choice == 4) {
            edit_board(&gta_board);      // calls the edit board function
        }
    
        else if (choice == 5) {
            char filename[100];
            printf("Enter filename to save the board (e.g., board.txt): ");
            fgets(filename, sizeof(filename), stdin);                   // read filename
            filename[strcspn(filename, "\n")] = '\0';                   // remove newline                
            save_board_to_file(&gta_board, filename);                   // call the save function
        }
            
        else if (choice == 6) {
            printf("Exiting the program...\n");         // exit program if user chooses 6
            break;
        } 
        else {
            printf("Feature not implemented yet.\n");   // for all other options not yet written
        }
    }

    //ascii art (because it is a shooting game)
    printf("               _____________________________,                   -    _  ♡\n");
    printf("              /_________I                  ()                           -_  - ♡ \n");
    printf("              \\    ___-     _____________/          \n");
    printf("              /  /      /   /__/                       \n");
    printf("            /  /___-/  /                             \n");
    printf("          /_______-/                                \n");
    return 0;
}

